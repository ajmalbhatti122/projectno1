import logo from './logo.svg';
import './App.css';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { Child } from './componets/child/child';
function App() {
  return (
    <div>
      <Child></Child>
    <ToastContainer>
      
    </ToastContainer>
    </div>
  );
}

export default App;
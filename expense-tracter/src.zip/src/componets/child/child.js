import './child.css'
import { useDispatch, useSelector } from 'react-redux'
import {useForm} from 'react-hook-form';
import { toast } from 'react-toastify';
import { useState } from 'react';

export function Child(){

    // let {num1 ,setNum1} = useState(0);
    // let {num2 ,setNum2} = useState(0);
    // let {total ,setTotal} = useState(num1 + num2)

let dispatch = useDispatch();
    
    

    let {register , handleSubmit} = useForm();


    let transection = useSelector(function(store){
        return store.adExpence
    })

    function getIncome(){
        let income = 0;

      transection.expense.map(function(a){
        console.log(a);
        if(a.amount > 0){
            income = income +  +a.amount
        }
      })
      return income;
        
    }

    function getExpense(){
        let expense = 0;
       
      transection.expense.map(function(b){
        console.log(b);
        if(b.amount < 0){
            expense +=  +b.amount
        }
      })
      return expense

    }

    const onSave = (formData) =>{

        console.log(formData);
        dispatch({
            type : 'Add-Expense',
            data : formData

        })
        toast.success('Tranaction add ho gai ha')

    }

    let income = getIncome();
    let expense = Math.abs(getExpense());

    return <div className='container'>
        <h1 className='text-center'>Expense Tracker by M.Ajmal</h1>

        <h3>You Balence <br /> {income - expense} </h3>

        <div className='expense-container'>
            <h3>INCOME <br /> {income}</h3>
            <h3>EXPENCE <br /> {expense}</h3>
        </div>

        <h3>History</h3>

        <hr />
        <ul className='transection-list'>

                    {
                    transection.expense.map(function(daata,maraindex){
                        return <li id='main-list' onClick={function(){
                            dispatch({
                                type:'delete-hogya',
                                del:maraindex
                            })
                        }}> 
                        <button id='X'>X</button>
                        <span>{daata.desc}</span>
                        <span>{daata.amount}</span>
                    </li>
                    })
                    }

               
        
        </ul>

        <h3>Add New Transection</h3>

        <hr />

        <form onSubmit={handleSubmit(onSave)} className='transection-form'>
            <label>
                Enter Discription <br />
                <input {...register('desc')} type="text"  required />
            </label>
            <br />
            <label>
                Enter Amount <br />
                <input {...register('amount')} type="number" required />
            </label>
            <br />
            <input type="submit" value='Add Transection' />
            
        </form>
    </div>
}

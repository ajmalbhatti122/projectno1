import {createStore  , combineReducers} from 'redux';



let myStore = {
    expense: [
       
    ]
}

function adExpence(oldData = myStore , newData){
    oldData = {...oldData}
    if(newData.type == 'Add-Expense'){
        oldData.expense.push(newData.data)

    }else if(newData.type =='delete-hogya'){
        oldData.expense.splice(newData.del,1)
    }
    return oldData

}

let Reduser = combineReducers({adExpence})

export let meraStore = createStore(Reduser);